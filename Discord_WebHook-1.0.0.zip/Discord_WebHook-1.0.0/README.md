# Usini Discord WebHook

A simple Arduino Library to send message on Discord using webhook.   
Based on my previous code https://github.com/maditnerd/discord_test

Compatible with ESP32/8266

Check **examples** to learn how to use it

This software is written by Rémi Sarrailh for µsini and is licensed under the MIT license.   
Check License.txt for more information